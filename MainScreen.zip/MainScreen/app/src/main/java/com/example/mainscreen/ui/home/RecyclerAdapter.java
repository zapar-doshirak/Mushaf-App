package com.example.mainscreen.ui.home;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mainscreen.R;

import java.util.List;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{

    private static final int TYPE = 1;
    private final Context context;
    private final List<Object> listRecyclerItem;

    public RecyclerAdapter(Context context, List<Object> listRecyclerItem) {
        this.context = context;
        this.listRecyclerItem = listRecyclerItem;
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder{

        private TextView number;
        private TextView name;
        private TextView place;
        private TextView ayahsCount;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);

            number = (TextView) itemView.findViewById(R.id.surahsNumberView);
            name = (TextView) itemView.findViewById(R.id.surahsNameView);
            place = (TextView) itemView.findViewById(R.id.surahPlaceView);
            ayahsCount = (TextView) itemView.findViewById(R.id.surahAyahsCountView);
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        switch (viewType){
            case TYPE:

            default:

                View layoutView = LayoutInflater.from(parent.getContext()).inflate(
                        R.layout.list_item, parent, false
                );

                return new ItemViewHolder(layoutView);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        int viewType = getItemViewType(position);

        switch (viewType){
            case TYPE:
            default:

                ItemViewHolder itemViewHolder = (ItemViewHolder) holder;
                Sures sures = (Sures) listRecyclerItem.get(position);

                itemViewHolder.number.setText(sures.getNumber());
                itemViewHolder.name.setText(sures.getName());
                itemViewHolder.place.setText(sures.getPlace());
                itemViewHolder.ayahsCount.setText(sures.getAyahsCount());
        }

    }

    @Override
    public int getItemCount() {
        return listRecyclerItem.size();
    }
}
